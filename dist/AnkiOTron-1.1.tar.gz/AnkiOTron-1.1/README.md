# AnkiCardOTron
Automates the creation of Anki cards for studying Hebrew-English
